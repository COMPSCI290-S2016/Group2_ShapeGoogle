# S3DGLPy
Simple 3D Geometry Library for Python
